/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Faaiz
 */
public class MyPriorityQueueTest {
    
    public MyPriorityQueueTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Add method, of class MyPriorityQueue.
     */
    @Test
    public void testAdd() {
        System.out.println("Add");
        List<String> l = new ArrayList<String>();
        List<String> m = new ArrayList<String>();
        List<String> n = new ArrayList<String>();
        l.add("x");
        l.add("y");
        m.add("a");
        m.add("b");
        n.add("yes");
        n.add("it worked");
        MyPriorityQueue instance = new MyPriorityQueue();
        instance.Add(l, 12);
        instance.Add(m, 23);
        instance.Add(n, 11);
        
        // TODO review the generated test code and remove the default call to fail.
        for(String next:instance.Remove())
        {
            System.out.println(next);
        }
        for(String next:instance.Remove())
        {
            System.out.println(next);
        }
        for(String next:instance.Remove())
        {
            System.out.println(next);
        }
    }

   
    /**
     * Test of isEmpty method, of class MyPriorityQueue.
     */
    @Test
    public void testIsEmpty() {
        System.out.println("isEmpty");
        MyPriorityQueue instance = new MyPriorityQueue();
        List<String> n = new ArrayList<String>();
        n.add("x");
        instance.Add(n,0);
        boolean expResult = false;
        boolean result = instance.isEmpty();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
    
}
