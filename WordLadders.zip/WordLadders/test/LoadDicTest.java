/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Faaiz
 */
public class LoadDicTest {
    
    public LoadDicTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of json_read method, of class LoadDic.
     */
    
    public void testJson_read() {
        System.out.println("json_read");
        LoadDic instance = new LoadDic("d.txt");
        List<String> words = instance.readJson();
        for(String temp:words)
        {
            System.out.println(temp);
        }
    

        // TODO review the generated test code and remove the default call to fail.
       
    }
   
    @Test
    public void testGenerateGraph()
    {
        System.out.println("Graph test");
        LoadDic instance = new LoadDic("d.txt");
        List<String> Words=instance.readJson();
        List< Map<String,GraphNode>> Graph=instance.generateGraph();
        
      
        for(String temp:Words)
              System.out.println(Graph.get(temp.length()-1).get(temp).getWord());
       
        System.out.println("------------------------------------");
        List< Map<String,GraphNode>> Graph0=instance.generateGraph();
        System.out.println("------------------------------------");
         for(String temp:Words)
              System.out.println(Graph0.get(temp.length()-1).get(temp).getWord());
        
        
    }
    
}
