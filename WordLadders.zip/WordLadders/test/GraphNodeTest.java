/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Faaiz
 */
public class GraphNodeTest {
    
    public GraphNodeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     
   

    /**
     * Test of WordLength method, of class GraphNode.
     */
    @Test
    public void testWordLength() {
        System.out.println("WordLength");
        String name="pole";
        GraphNode instance = new GraphNode(name,"d.txt");
        int expResult = 4;
        int result = instance.WordLength();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       }

    

    /**
     * Test of getActions method, of class GraphNode.
     */
    @Test
    public void testGetActions() {
        System.out.println("getActions");
        String name="POLE";
        GraphNode instance = new GraphNode(name,"d.txt");
        List<String> result = instance.getActions();
        for(String temp:result)
            System.out.println(temp);
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
