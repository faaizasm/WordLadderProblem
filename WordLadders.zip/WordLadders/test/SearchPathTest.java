/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Faaiz
 */
public class SearchPathTest {
    
    public SearchPathTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of heuristic method, of class SearchPath.
     */
  /* @Test
    public void testHeuristic() {
        System.out.println("heuristic");
        String current = "marm";
        SearchPath instance = new SearchPath("d.txt");
        int expResult = 1;
        int result = instance.heuristic(current);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }
*/
    /**
     * Test of AstarSearch method, of class SearchPath.
  */
    
    @Test
    public void testAstarSearch()  {
        System.out.println("AstarSearch");
        LoadDic load=new LoadDic("d.txt");
        List<String> Words=load.readJson();
        SearchPath instance = new SearchPath("d.txt");
        List<String> result  = instance.AstarSearch("CARD","WARM");
        
        
        for(String s:result)
        {
                
                    System.out.print(s);
                  //  if(!temp.equals(result.get(instance.getCostofPath(result))))
                    System.out.print("->");

                }
                System.out.println("");
             }
           
    
    
     @Test
    public void testAllAstarSearch()  {
        System.out.println("AstarSearch");
        LoadDic load=new LoadDic("d.txt");
        int words=0,total=0,found=0,notfound=0,unidentified=0;
        List<Integer> Path =new ArrayList<Integer>();
        List<String> dest = load.SortOnWordLength().get(15);
        
        SearchPath search=new SearchPath("d.txt");
        Map<String,Map<String,List<String>>> Record=search.ExecuteSearchAll();
        List<String> longest=search.GetLongest();
        
        System.out.println("LONGEST PATH FOUND");
        System.out.println(search.GetLongestLength()+" NODES");
        for(String lng:longest)
            System.out.print(lng+"->");
        System.out.println("");
        
        /*for(String t:dest)
        {
             System.out.println("DESTINATION: "+t);
             for(String l:Record.get("LABYRINTHIBRANCH").get(t))
                System.out.print(l+"->");
             System.out.println("");    
        }
       */
        
    }
   
    /**
     * Test of getCostofPath method, of class SearchPath.
     */
    /*@Test
    public void testGetCostofPath() {
        System.out.println("getCostofPath");
        SearchPath instance=new SearchPath("","","");
        List<String> arg = new ArrayList<String>();
        arg.add("n1");
        arg.add("n2");
        arg.add("n3");
        arg.add("n4");
        arg.add("n5");
        
        int expResult = 4;
        int result = instance.getCostofPath(arg);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
   
    }
    */
}
