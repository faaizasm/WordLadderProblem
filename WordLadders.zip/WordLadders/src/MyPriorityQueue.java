
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Faaiz
 */
public class MyPriorityQueue {
    List<List<String>> Path=new ArrayList<List<String>>();
    List<Integer> Priority=new ArrayList<Integer>();
    
    public void Add(List<String> l,int p)
    {
        Path.add(l);
        Priority.add(p);
    }
    public List<String> Remove()
    {
        
        int prev = Priority.get(0);
        int lowest = Priority.get(0);
        int index=0;
        int indexp=0;
        int indexl=0;
        List<String> nothing=new ArrayList<String>();
        for(int temp:Priority)
        {
            if(temp < prev)
            {
                lowest=temp;
                indexp=index;
            }
            else
                lowest=prev;
            prev=lowest;
            index++; 
            
        }
     
        Priority.remove(indexp);
        
        for(List<String> temp:Path)
        {
            if(indexl==indexp)
            {
                Path.remove(temp);
                return temp;
            }
            indexl++;
        }
        System.out.println("Empty");
        return nothing; 
    }
    public boolean isEmpty()
    {
        int index=0;
        for(List<String> temp : Path)
            index++;
        return index==0;
    }
    public List<String> Get(int i)
    {
        List<String> n = new ArrayList<String>();
        int count=0;
        for(List<String> temp:Path)
            if(count==i)
                return temp;
        System.out.println("not found!");
        return n;
    }
    public List<List<String>> GetAll()
    {
        return Path;
    }
    
    
}
