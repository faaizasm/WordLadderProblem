
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Faaiz
 */
public class GraphNode {
    String word;
    List<String> actions =new ArrayList<String>();
    String filePath;
    
    GraphNode(String temp,String path)
    {
        word=temp;
        filePath=path;
        
    }
    public String getWord()
    {
        return word;
    }
      
    public int WordLength()
    {
        return word.length();
    }
    
    
   
     public List<String> getActions()
     {
         if((actions!=null)&&!(actions.isEmpty()))
         {
           //  System.out.println("Already calculated");
             return actions;
         }
         //System.out.println("Calculating");
         LoadDic load=new LoadDic(filePath);
         
         List<String> Words = load.SortOnWordLength().get(word.length()-1);
         int dif;
         for(String temp:Words )
         {
             dif=0;
             //System.out.println(temp+" vs "+word);
             if(temp.length()==word.length())
                 for(int x=0;x<WordLength();x++)
                {
                     if(temp.charAt(x)!=word.charAt(x))
                     dif++;
                }
             if(dif==1)
                 actions.add(temp);
         }
         return actions;
     }
     
}
