
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Faaiz
 */
public class testMain {
   
    public static void main(String[] args) {
        
        
        LoadDic load=new LoadDic("d.txt");
        //int words=0,total=0,found=0,notfound=0,unidentified=0;
        List<Integer> Path =new ArrayList<Integer>();
        List<String> dest = load.SortOnWordLength().get(15);
        
        SearchPath search=new SearchPath("d.txt");
        
        
        
        System.out.println("TASK : All Nodes to All + Longest Path");
        Map<String,Map<String,List<String>>> Record=search.ExecuteSearchAll();
        List<String> longest=search.GetLongest();
        
        System.out.println("LONGEST PATH FOUND");
        System.out.println(search.GetLongestLength()+" NODES");
        for(String lng:longest)
            System.out.print(lng+"->");
        System.out.println("");
        
        System.out.println("------------------------------");
        
        
        
        
        
        
        System.out.println("TASK: One Node to Other");
        
        List<String> result  = search.AstarSearch("BEST","GOOD");
        
        
        for(String s:result)
        {
                
                    System.out.print(s);
                  //  if(!temp.equals(result.get(instance.getCostofPath(result))))
                    System.out.print("->");

                }
                System.out.println("");
        
         System.out.println("------------------------------");
        
        
        
        
        
        
        System.out.println("TASK: Return Null");
        search.ShowNulls();
        
        
        
        System.out.println("------------------------------");
        
        
        
        
        
        
        System.out.println("TASK: Frequency Distribution");
        int [] freq=new int[100];
        freq=search.GetFreq();
        for(int x=0;x<100;x++)
        {
            System.out.println(x+"         "+freq[x]);
        }
    }
    
}

    
