
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Faaiz
 */
public class LoadDic {
   static List<List<String>> wordSameLength;
   static List<String> wordList;
   static List<Map<String,GraphNode>> Graph;
   List<Map<String,GraphNode>>  Alt= new ArrayList<Map<String,GraphNode>>();
   String filePath;

	// @param path of json file
	// This function loads the words from json stream
	// @return: wordList
        LoadDic(String Path)
        {
            filePath=Path;
        }
	public List<String> readJson() {
		
		if(wordList!=null)
                {
                    
                    
                    return wordList;
                }
              System.out.println("Reading File");
                wordList = new ArrayList<String>();
		JSONParser parser = new JSONParser();
		try {
                  
			 
            Object obj = parser.parse(new FileReader(filePath));
            JSONObject jsonObject = (JSONObject) obj;
            Set<String> wrd = jsonObject.keySet();
            // Adding words to the wordList
            Iterator<String> iterator = wrd.iterator();
            while (iterator.hasNext()) {
            	wordList.add(iterator.next());
                //System.out.println(iterator.next());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
		return wordList;
    }
   public int findMaxLength()
   {
       readJson();
       int maxLength=0;
       for(String temp:wordList)
           if(temp.length()>maxLength)
               maxLength=temp.length();
       return maxLength;
   }
   public List<List<String>> SortOnWordLength()
   {

       if(wordSameLength!=null)
           return wordSameLength;
       wordSameLength=new ArrayList<List<String>>();
       int maxLength=findMaxLength();
       readJson();
       List<String> sameLength ;

       for(int x=0;x<maxLength;x++)
       {
           sameLength = new ArrayList<String>();
           for(String temp:wordList)
                if(temp.length() == (x+1))
                    sameLength.add(temp);
                
                
           
           
 
           wordSameLength.add(sameLength);
 
       }
      
       return wordSameLength;
   }

 
   
   public List<Map<String,GraphNode>> generateGraph()
   {
       
       if((Graph!=null)&&(!Graph.isEmpty()))
           
       {
           return Graph;
       }
       
       readJson();
       
       int max=findMaxLength();
       Map<String,GraphNode> TempG=new HashMap();
       
       for(int x=0;x<max;x++)
       { 
           TempG=new HashMap();
           for(String temp: wordList)
               if(temp.length() == (x+1))
                    TempG.put(temp,new GraphNode(temp,filePath));
           Alt.add(TempG);
       }
       Graph=Alt;
       
       return Alt;
   }
   
   
}
