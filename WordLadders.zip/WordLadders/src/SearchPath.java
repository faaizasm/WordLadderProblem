
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.Stack;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Faaiz
 */
public class SearchPath
{
    int cost;
    String source;
    String destination;
    String filePath;
    static int[] freq = new int[100];
   
    static List<String> longest;
    static int longLength=0;
    static Map<String,Map<String,List<String>>> Record;
    static boolean Recordinit;
    SearchPath(String Path)
    {
        filePath=Path;
        for (int x=0;x<100;x++)
            freq[x]=0;
        
    }
    
    
    
    public boolean validateSearch()
    {
        boolean validateS=false;
        boolean validateD=false;
        boolean validate=false;
        LoadDic load=new LoadDic(filePath);
        List<String> Words = load.readJson();
        if(source.length()!=destination.length())
        {
            System.out.println("ERROR! Word lengths do not match");
            return validate;
        }
        for(String temp: Words)
        {
            if(temp.equals(source))
                validateS=true;
            if(temp.equals(destination))
                validateD=true;
        }
        if((validateS==true)&&(validateD==true))
            validate=true;
        else 
            System.out.println("Error! Not found in dictionary");
        return validate;
    }
    
    public int heuristic(String current)
    {
        int h=0;
        for(int x = 0;x < current.length();x++)
            if(current.charAt(x)!=destination.charAt(x))
                h++;
        return h;
    }
    
    
    public List<String> AstarSearch(String src,String dest)
    {
        
        source=src;
        destination=dest;
        List<String> nothing=new ArrayList<String>();//returned if path not found
        if(!validateSearch())
            return nothing;
        LoadDic load=new LoadDic(filePath);
        Map<String,GraphNode> Graph = load.generateGraph().get(source.length()-1);
        String s;
        
        List<String> temp = new ArrayList<String>() ;
        MyPriorityQueue Frontier=new MyPriorityQueue();
        List<String> Path=new ArrayList<String>();
        List<String> Explored=new ArrayList<String>();
        List<String> front=new ArrayList<String>();
        cost=0;
        boolean actExplored = false;
        boolean checkFront=false;
        
       
        Path.add(source);
        Frontier.Add(Path,heuristic(source));
        while(!Frontier.isEmpty())
        {    
            Path=Frontier.Remove();
            
            
            
            s = Path.get( getCostofPath(Path));
            
            if (s.equals(destination))
                return Path;
            Explored.add(s);
            
            
            for(String act:Graph.get(s).getActions())
            {
                actExplored=false;
                checkFront=false;
                
                for(String check:Explored)
                    if(check.equals(act))
                        actExplored=true;
                for(String check:front)
                    if(check.equals(act))
                        checkFront=true;

                if(!actExplored && !checkFront)
                { 
                    temp=new ArrayList<String>();
                    Path.add(act);
                    temp.addAll(Path);
                    Frontier.Add(temp,getCostofPath(Path)+heuristic(act));
                    Path.remove(act); 
                    front.add(act);
                    
                }
                
                
                
                
            }
           
          
            
        }
       System.out.println("nothing");
        return nothing;
        
    }
    public boolean CheckRecord()
    {
        if((Record!=null)&&(!Record.isEmpty()))
        {
            //System.out.println("old");
            Recordinit=true;
        }
        else
            Recordinit=false;
        return Recordinit;
                    
    }
    public void InitializeRecord()
    {
        if(!CheckRecord())
        {
            int count=0;
            int icount=0;
     
            Record = new HashMap();
            LoadDic load=new LoadDic(filePath);
            List<String> Words=load.readJson();
            for(String temp1:Words)
            {
                
                Record.put(temp1, new HashMap());
                
            }
        }
    }
    
  
      public Map<String,Map<String,List<String>>> ExecuteSearchAll()
    {
        boolean checkKey=false;
        LoadDic load=new LoadDic(filePath);
        List<String> Words=load.readJson();
        List<List<String>> Dest=load.SortOnWordLength();
        int total=0,found=0,notfound=0;
        for(String src:Words)
        {
            Record=SearchAll(src);
            
          
           total++;
           if(total%100==0)
           {
               System.out.println("TOTAL WORDS TRAVERSED : " +total);
              
           }
        }
        return Record;
    }
               
     
    
        
   public Map<String,Map<String,List<String>>> SearchAll(String src)
     {
        source=src;
        
        if(longest==null)
            longest= new ArrayList<String>();
       // System.out.println("destination"+dest);
        //System.out.println("check");
        InitializeRecord();
        //System.out.println("check");
        Map<String,Map<String,List<String>>> nothing=new HashMap();//returned if path not found
       // if(!validateSearch())
         //   return nothing;
        //System.out.println("check");
        
        //System.out.println("check");
        
        //Map<String,Map<String,List<String>>> RecordHolder=new HashMap();
        LoadDic load=new LoadDic(filePath);
        Map<String,GraphNode> Graph = load.generateGraph().get(source.length()-1);
        String s;
        int localLongest=0;
        int length=0;
      
        List<String> locLong = new ArrayList<String>() ;
        //List<String> Words=load.readJson();
        List<List<String>> SameLength=load.SortOnWordLength();
        List<String> temp = new ArrayList<String>() ;
        Queue<List<String>> Frontier=new Queue<List<String>>();
        List<String> Path=new ArrayList<String>();
        List<String> Explored=new ArrayList<String>();
        List<String> front=new ArrayList<String>();
        boolean checkKey=false;
        boolean checkNull=false;
        cost=0;
        int count=0;
        boolean actExplored = false;
        boolean checkFront=false;
        front.add(source);
        Path.add(source);
        Frontier.enqueue(Path);
      
        while(Frontier.hasItems())
        {    
            
            length=0;
            Path=Frontier.dequeue();
            
            
            
            s = Path.get(getCostofPath(Path));
            //System.out.println("s: "+s);
           
            
            Explored.add(s);
            
            
            for(String act:Graph.get(s).getActions())
            {
                actExplored=false;
                checkFront=false;
                //System.out.println("ACTION: "+act); 
                for(String e:Explored)
                {
          
                   // System.out.println("Explored : "+ e);
                    //System.out.println("------------------");
                    //System.out.println("Act : "+act);
                    //System.out.println("------------------");
                    
                    
                    if(e.equals(act))
                        {
                      //  System.out.println(e+"=EXPLORED");
                        actExplored=true;
                        }
                }
                
                for(String f:front)
                {    if(f.equals(act))
                        {
                     //   System.out.println(f+"=FRONT");
                        actExplored=true;
                        }
                }
                if(!(actExplored) && !(checkFront))
                {
                    
                    length=0;
                    Path.add(act);
                    temp=new ArrayList<String>();  
                    temp.addAll(Path);
                    
                     checkKey=false;
                                //System.out.println("check"); 
                                for(String key:Record.get(src).keySet())
                                         if (key.equals(act))
                                         {

                                              // System.out.println(key); 
                                             checkKey=true;
                                         }

                    if(!checkKey)
                      // for(String node:Path)
                        {
                            Record.get(src).put(act, new ArrayList());
                            for(String x:temp)
                            {
                                Record.get(src).get(act).add(x);
                                length++;   
                            }
                            freq[length]++;
                        }
                  
                     /* checkKey=false;
                                //System.out.println("check"); 
                                for(String key:Record.get(Lsrc).keySet())
                                         if (key.equals(Ldest))
                                         {

                                              // System.out.println(key); 
                                             checkKey=true;
                                         }

                                if(!checkKey)*/
                     
                           
                            Frontier.enqueue(temp);
                            Path.remove(act); 
                            front.add(act);
                        
                   
                    
                }
                
                
                
            }
            if(!Frontier.hasItems())
                for(String k:Record.get(src).keySet())
                {
                  if(k.equals(s))  
                    for(String p:Record.get(src).get(s))
                        localLongest++;
                    
                }
            if(localLongest>longLength)
            {
                longest =new ArrayList<String>();
                longLength=localLongest;
                for(String p:Record.get(src).get(s))
                    locLong.add(p);
                longest.addAll(locLong);
                    
            }
          
            
        }
          
        for(String n:SameLength.get(src.length()-1))
                     {
                         checkNull=false;
                     
                         for(String k:Record.get(src).keySet())
                         {
                           
                             if(k.equals(n))
                                 checkNull=true;
                         }
                         if(!checkNull) 
                         {
                             Record.get(src).put(n,new ArrayList());
                             Record.get(src).get(n).add("NULL");
                             freq[0]++;
                             
                         }
                     }
                         
                             
        return Record;
        
    }
    
    public List<String> GetLongest()
    {
        return longest;
    }
     public int GetLongestLength()
    {
        return longLength;
    }
     
    public void ShowNulls()
    {
        for(String src:Record.keySet())
        {
            for(String dst:Record.get(src).keySet())
                if(Record.get(src).get(dst).get(0).equals("NULL"))
                    System.out.println(src+"->"+dst);
        }
    } 
   
     
     
     
    
    
    public int getCostofPath(List<String> arg)
    {
        int cost=0;
        for(String temp:arg)
            cost++;
        return --cost;
        
    }
    public int[] GetFreq()
    {
        return freq;
    }
    
    
    
}
